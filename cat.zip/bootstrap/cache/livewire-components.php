<?php return array (
  'data.kolom-table' => 'App\\Http\\Livewire\\Data\\KolomTable',
  'data.paketsoal-table' => 'App\\Http\\Livewire\\Data\\PaketsoalTable',
  'data.peserta-table' => 'App\\Http\\Livewire\\Data\\PesertaTable',
  'data.soalkecermatan-table' => 'App\\Http\\Livewire\\Data\\SoalkecermatanTable',
  'latihan.riwayat-table' => 'App\\Http\\Livewire\\Latihan\\RiwayatTable',
  'managements.controllers-table' => 'App\\Http\\Livewire\\Managements\\ControllersTable',
  'managements.functions-table' => 'App\\Http\\Livewire\\Managements\\FunctionsTable',
  'managements.menu-table' => 'App\\Http\\Livewire\\Managements\\MenuTable',
  'managements.menugroups-table' => 'App\\Http\\Livewire\\Managements\\MenugroupsTable',
  'managements.modules-table' => 'App\\Http\\Livewire\\Managements\\ModulesTable',
  'managements.roles-table' => 'App\\Http\\Livewire\\Managements\\RolesTable',
  'user-table' => 'App\\Http\\Livewire\\UserTable',
);