<script>
    
    function soalkecermatanCrud() {
        return {
            successAlert: {
                open: false,
                message: ''
            },
            openModal : false,
        }
    }
</script>