<script>
    
    function profileCrud() {
        return {
            openModal : false,
            token : "{{ $user->id }}",
            successAlert: {
                open: false,
                message: ''
            },
            failedAlert: {
                open: false,
                message: ''
            },
            form: {
                name: "{{ $user->name }}",
                gender: "{{ $peserta->gender }}",
                birthdate: "{{ $peserta->birthdate }}",
                birthplace: "{{ $peserta->birthplace }}",
            },
            errMsg: {
                name: '',
                gender: '',
                birthdate: '',
                birthplace: '',
            },
            addData() {
                this.openModal = true
            },
            confirmSave() {
                
                Swal.fire({
                title: "Ubah profile",
                text: "pastikan data yang diinputkan sudah benar!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.saveData()
                    }
                })
            },
            async saveData() {
                    try {
                        const response = await axios.put('/profile/' + this.token, this.form)
                        if(response.status == 200) {
                            
                            Swal.fire({
                                icon: 'success',
                                title: response.data.message,
                                showConfirmButton: false,
                                timer: 1500
                            })

                            this.successAlert = {
                                open: true,
                                message: response.data.message
                            }
                            window.location.reload()
                        }
                    } catch (e) {
                        if(e.response.status == 422) {
                            console.log(e.response);
                            Swal.fire({
                                icon: 'error',
                                title: e.response.data.message,
                                showConfirmButton: false,
                                timer: 1500
                            })
                            let errors = e.response.data.errors;
                            Object.keys(this.errMsg).forEach(key => {
                                if(key !== "password_confirmation")
                                this.errMsg[key] = Array.isArray(errors[key]) ? errors[key].map((value) => {
                                return value;
                                }).join(' ') : errors[key]
                            });
                            
                        }
                    }
                
            }
        }
    }
</script>