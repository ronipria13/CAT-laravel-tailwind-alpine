
window.Swal = require('sweetalert2');