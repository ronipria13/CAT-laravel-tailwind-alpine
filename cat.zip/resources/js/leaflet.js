// require('leaflet/dist/leaflet.js.map');
window.L = require('leaflet/dist/leaflet.js');

