
window.TomSelect = require('tom-select');
